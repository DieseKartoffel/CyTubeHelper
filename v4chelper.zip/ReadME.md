## How to run:

### Temporay
#### 1. Download the folder
#### 2. Navigate Mozilla Firefox to: 
```
about:debugging
```
#### 3. Click "Add temporary plugin" and select manifest.json file
#### 4. Visit any cytu.be site
### Install
#### 1. Download "v4cplus-1.0-fx.xpi"
#### 2. Navigate Mozilla Firefox to: 
```
about:addons
```
#### 3. Go to "Extensions" and click the settings button. Choose "Install Addon from file" and select "v4cplus-1.0-fx.xpi"
#### 4. Visit any cytu.be site
