## How to run:
### 1. Download the folder
### 2. Navigate Mozilla Firefox to: 
```
about:debugging
```
### 3. Click "Add temporary plugin" and select manifest.json file
### 4. Visit any cytu.be site